---
name: 'Стартовая страница для браузера'
description: ''
tags: ['Vanilla']
image: '../../../public/projects/sbstartpage.webp'
link: 'https://seryibaran.github.io/SBStartpage/'
---
