---
name: 'Сайт-README для проекта "Privacy Search Companion"'
description: ''
tags: ['Vue', 'Tailwind']
image: '../../../public/projects/psc.webp'
link: 'https://seryibaran.github.io/PSC-Site/'
---
