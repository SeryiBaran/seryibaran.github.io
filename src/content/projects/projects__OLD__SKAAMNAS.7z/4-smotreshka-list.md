---
name: 'Список каналов для Смотрёшки'
description: 'То что сделали оригинальные разрабы на своем сайте не понравилось, написал свое'
tags: ['Vue', 'UnoCSS']
image: '../../../public/projects/smotreshka-list.webp'
link: 'https://seryibaran.github.io/smotreshka_list'
---
