---
name: 'Генератор картинок для теста монитора'
description: ''
tags: ['Vanilla', 'Canvas']
image: '../../../public/projects/dtpg.webp'
link: 'https://seryibaran.github.io/test-picture-generator/'
---
