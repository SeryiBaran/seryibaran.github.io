---
name: 'Простой лендинг'
description: ''
tags: ['Vanilla']
image: '../../../public/projects/maket-first.webp'
link: 'https://seryibaran.github.io/maket-agency/'
---
