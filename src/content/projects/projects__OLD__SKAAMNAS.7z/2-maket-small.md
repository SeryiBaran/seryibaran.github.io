---
name: 'Лендинг'
description: 'Лендинг с анимациями при скролле'
tags: ['Vanilla']
image: '../../../public/projects/maket-landing.webp'
link: 'https://seryibaran.github.io/maket-web-dev-project/'
---
