---
name: 'Макет агенства'
description: 'Довольно большой макет сайта с анимациями.'
tags: ['Vue', 'UnoCSS']
image: '../../../public/projects/maket-squareup-agency.webp'
link: 'https://seryibaran.github.io/maket__agencyvue'
---
